
import ChatContainer from "./components/ChatContainer";


function App() {
  return (
    <div style={{ backgroundColor: "#ece5dd", height: "100vh" }}>
      <h2>Chat</h2>


      <ChatContainer />
    </div>
  );
}

export default App;


